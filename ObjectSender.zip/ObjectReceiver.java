import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class ObjectReceiver {
	
	public static final int PORT = 12345; 
	public static final String SERVER_NAME = "localhost";
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		//ask for the amount of objects wanted
		System.out.print("Please enter how many objects you want: ");
		int amt = in.nextInt();
		//close scanner
		in.close();
		try {
			Socket socket = new Socket(SERVER_NAME, PORT);
			//send the amount of objects wanted
			PrintWriter outToSender = new PrintWriter(socket.getOutputStream(), true);
			outToSender.println(amt);
			//open objectStream and receive the list of objects
			ObjectInputStream inFromSender = new ObjectInputStream(socket.getInputStream());
			ArrayList<People> list = (ArrayList<People>) inFromSender.readObject();
			//print objects
			for(People p: list) {
				System.out.print(p.toString());
			}
			//sender will close the connection
		}
		catch (Exception e) {
			System.err.println("Something went wrong trying to recieve the objects");
			e.printStackTrace();
		}
	}
}
