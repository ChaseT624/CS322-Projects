import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;

public class ObjectSender {
	 
	public static final int PORT = 12345; 
	
	public static void main(String[] args) {
		Random random = new Random();
		//Create the arrayList
		ArrayList<People> list = new ArrayList<People>();
		try {
			//Create a server
			ServerSocket server = new ServerSocket(PORT);
			Socket socket = server.accept();
			//Make reader to get amount of Objects wanted
			BufferedReader inFromClient = new BufferedReader(
					new InputStreamReader(socket.getInputStream()));
			String line = inFromClient.readLine();
			int people = Integer.parseInt(line);
			//make the objects
			for (int i = 0; i < people; ++i) {
				
				list.add(new People(random.nextInt(People.NAMES.length),
						random.nextInt(99) + 1, random.nextInt(1000)));
			}
			//send the objects and close the connection
			ObjectOutputStream outToReceiver = new ObjectOutputStream(socket.getOutputStream());
			outToReceiver.writeObject(list);
			socket.close();	
		}
		catch (Exception e) {
			System.err.println("Something went wrong with the transmission");
			e.printStackTrace();
		}
	}
}
