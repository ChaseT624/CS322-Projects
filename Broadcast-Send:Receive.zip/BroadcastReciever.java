import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class BroadcastReciever {
 
	public static final int PORT = 12346;
	public static final int SENDER_PORT = 12347;
	
	public static void main(String[] args) throws IOException {
		//wait for packet
		DatagramSocket socket = new DatagramSocket(PORT);
		byte[] incoming = new byte[126];
    	DatagramPacket in = new DatagramPacket(incoming, incoming.length);
    	socket.receive(in);
    	//store IP
    	InetAddress sender = in.getAddress();
    	//put byte array into a string
    	String message = "";
    	for (int i = 0; i < in.getLength(); i+= 2) {
    		int first = in.getData()[i];
    		int second = in.getData()[i+1];
    		char c = (char)((first << 8) | second);
    		message += c;
    	}
    	System.out.println(message);
    	//if this is the correct string respond 
    	if (message.equals("Please respond within five seconds to be added to the list\n")) {
    		byte[] response = new byte[2];
    		char x = 'x';
    		response[0] = (byte) ((byte) x << 8);
	    	response[1] = (byte) x;
	    	DatagramPacket out = new DatagramPacket(response, response.length, InetAddress.getByName("localhost") , SENDER_PORT);
    		socket.send(out);
    	}
	}
}
