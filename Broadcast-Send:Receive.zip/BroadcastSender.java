import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import javax.swing.Timer;

public class BroadcastSender {

	public static final int CLIENT_PORT = 12346;
	public static final int PORT = 12347;
	public static final int TIME_OUT = 10000;
	
	public static void main(String[] args) throws UnknownHostException, SocketException {
		DatagramSocket socket = new DatagramSocket(12347);
		Timer timer = new Timer(10000, timeOut);
		timer.stop();
		//make message and put it into byte array
		String message = "Please respond within five seconds to be added to the list\n";
		byte[] packet = new byte[message.length() * 2];
		int bytes = 0;
		for (int i = 0; i < message.length(); ++i) {
			char c = message.charAt(i);
			packet[bytes++] = (byte) ((byte) c << 8);
	    	packet[bytes++] = (byte) c;
		}
		//send out packet to network
		InetAddress broadcast = InetAddress.getByName("localhost");
		socket.setBroadcast(true);
		DatagramPacket data = new DatagramPacket(packet, packet.length, broadcast , CLIENT_PORT);
		try {
			socket.send(data);
		} catch (IOException e1) {
			System.err.println("error sending data");
		}
		//restart timer and wait for timeout
		timer.restart();
		while (true) {
			byte[] incoming = new byte[1];
        	DatagramPacket in = new DatagramPacket(incoming, incoming.length);
			try {
				//Receive packet and print address of who replied
				socket.receive(in);
		        InetAddress responder = in.getAddress();
		        System.out.println(responder + " replied");
			}
			catch(Exception e) {
				System.err.println("Error reciving data");
				e.printStackTrace();
			}
		}
	
	}
	
	static ActionListener timeOut = new ActionListener() {
		//when the timer calls terminate the program
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
		}
	};
}

