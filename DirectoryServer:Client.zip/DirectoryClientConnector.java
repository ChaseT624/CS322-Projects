import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class DirectoryClientConnector implements Runnable {

	private String serverName;
	private int port;
	private String name;
	private int id; 
	private int ttl;
	private long lastCheck;
	private Thread pinger;
	boolean login;
	
	public DirectoryClientConnector(String serverName, int port, String name) {
		this.serverName = serverName;
		this.port = port;
		this.name = name;
		login = false;
	}
	
	public void logon() throws Exception {
		//check to see if this object is logged in
		if (login == true) {
			throw new Exception();
		}
		//try connecting to the server
		try ( Socket socket = new Socket(serverName, 54321);
				BufferedReader inFromServer = new BufferedReader(
						new InputStreamReader(socket.getInputStream()));
				PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);
				)
		{	
			//put in the logon and request and take back what message you get
			String msg = "LOGON " + port + " " + name;
			outToServer.println(msg);
			System.out.println("Sending: " + msg);
			String reply = inFromServer.readLine();
			//check for id number being given to us by checking between the two colons
			int firstCheck = reply.indexOf(":");
			int secondCheck = reply.lastIndexOf(":");
			//check to see if an error message was given 
			if (reply.substring(0, firstCheck).equals("ERROR")) {
				throw new Exception();
			}
			else {
				login = true;
				//save the id given 
				System.out.println("Server resp: " + reply);
				String id = reply.substring(firstCheck +1, secondCheck);
				this.id = Integer.parseInt(id);
				//save the ttl given and the last the server was accessed
				lastCheck = System.currentTimeMillis();
				ttl = Integer.parseInt(reply.substring(secondCheck+1));
				//create thread to PING 
				pinger = new Thread(this);
				pinger.start();
			}
		}
		catch (Exception e) {
			throw new Exception("There was an error logging on");
		}
	}

	public ArrayList<String> getList() throws Exception {
		//try connecting to the server
		try ( Socket socket = new Socket(serverName, 54321);
		BufferedReader inFromServer = new BufferedReader(
		new InputStreamReader(socket.getInputStream()));
		PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);
								)
		{	
			//Ask for a List from the server
			String msg = "LIST " + id;
			outToServer.println(msg);
			System.out.println("Sending: " + msg);
			String reply = inFromServer.readLine();
			//check for valid response		
			int colon = reply.indexOf(":");
			if (reply.substring(0, colon).equals("ERROR")) {
				throw new Exception();
			}
			else {
				System.out.println("Server resp: " + reply);
				//Create the array list
				//Don't add first line since it is not client info
				ArrayList<String> list = new ArrayList<String>();
				//while the input server has more to read add them to the end list
				while(inFromServer.ready()) {
					String next = inFromServer.readLine();
					list.add(next);
					System.out.println(next);
				}
				//return the list
				return list;
			}
			
		}
		catch (Exception e) {
			throw new Exception("Error getting a List");
		}
	}
	
	public void logoff() throws Exception {
		//try connecting to the server
		try ( Socket socket = new Socket(serverName, 54321);
		BufferedReader inFromServer = new BufferedReader(
		new InputStreamReader(socket.getInputStream()));
		PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);
						)
		{	
			//logoff the server
			String msg = "LOGOFF " + id;
			outToServer.println(msg);
			System.out.println("Sending: " + msg);
			String reply = inFromServer.readLine();
			//check for valid response		
			int colon = reply.indexOf(":");
			if (reply.substring(0, colon).equals("ERROR")) {
				throw new Exception();
			}
			else {
				login = false;
				System.out.println("Server resp: " + reply);
				//stop the thread pinging 
				pinger.interrupt();
			}
			
		}
		catch (Exception e) {
			throw new Exception("There was an error logging off");
		}
	}
	
	void ping() throws Exception {
		//try connecting to the server
		try ( Socket socket = new Socket(serverName, 54321);
		BufferedReader inFromServer = new BufferedReader(
		new InputStreamReader(socket.getInputStream()));
		PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);)
		{
			outToServer.println("PING " + id+"\n");
			String reply = inFromServer.readLine();
			//check for valid response		
			int colon = reply.indexOf(":");
			if (reply.substring(0, colon).equals("ERROR")) {
				
				throw new Exception();
			}
			else {
				//update last time you pinged and check for a new ttl 
				lastCheck = System.currentTimeMillis();
				if ((Integer.parseInt(reply.substring(colon+1)) != ttl)) {
					ttl = Integer.parseInt(reply.substring(colon+2));
				}
			}
		}
		catch (Exception e) {
			throw new Exception("There was an error pinging");
		}					
	}
	
	public void run() {
		boolean valid = true;
		while (valid) {
			//check to see if interrupted 
			if (pinger.isInterrupted()) {
				valid = false; 
			}
			//If not interrupted PING halfway into the ttl
			else if ((System.currentTimeMillis() - lastCheck)/1000 > ttl/2) {	
				try {
					ping();
				} catch (Exception e) {
					System.out.println("There was a problem pinging");
				}
			}
		}
	}
}


