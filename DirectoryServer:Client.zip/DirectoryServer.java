import java.io.*;
import java.net.*;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;

public class DirectoryServer {

	public static final int TTL = 5;
	public static final int PORT = 54321;
	public static int id = 1;
	
	public static void main(String[] args) {
		try {
			//Create a server
			ServerSocket server = new ServerSocket(PORT);
			Hashtable<Integer, Client> clients = new Hashtable<Integer, Client>();
			while (true) {
				//Listen for a connection
				Socket socket = server.accept();
				//set up Network input and output.
				BufferedReader inFromClient = new BufferedReader(
						new InputStreamReader(socket.getInputStream()));
				
				//setup PrintWriter with automatic line flushing
				PrintWriter outToClient = new PrintWriter(socket.getOutputStream(), true);
				String line = inFromClient.readLine();
				//Clear expired in list
				removeExpired(clients);
				//Check for the 4 specified commands
				if (line.contains("LOGON")) {
					//find the first and last space in order 
					//to find the location of the port and alias in the String
					int firstSpace = line.indexOf(" ");
					int lastSpace = line.lastIndexOf(" ");
					//if there is not two spaces, nothing after the last space, 
					//or LOGON is not first give an error message
					if (firstSpace == lastSpace || lastSpace == line.length() -1 ||  
							!line.substring(0, firstSpace).equals("LOGON")) {
						outToClient.println("ERROR: That is not a valid command\n");
					}
					else {
						String clientPort = line.substring(firstSpace+1, lastSpace);
						//make sure port number is an integer
						try {
							int clientPortNum = Integer.parseInt(clientPort);
						}
						catch(Exception ex) {
							outToClient.println("ERROR: That is not a valid port number\n");
							//close the socket and restart the loop if it is not
							socket.close();
							continue;
						}
						int clientPortNum = Integer.parseInt(clientPort);
						String clientAlias = line.substring(lastSpace+1);
						//Create a client and add them to the list with a new id
						Client currClient = 
								new Client(socket.getInetAddress().getHostAddress(), clientPortNum, clientAlias);
						//Check if this client is already logged on
						Collection<Client> values = clients.values();
						//check if a client is the same
						boolean same = false;
						for (Client checkClient : values) {
							//if they are already logged on set the variable to true
							if (checkClient.same(currClient)) {
								same = true;
							}	
						}
						//if client is the same give an error 
						if (same == true) {
							outToClient.println("ERROR: You are already logged on\n");
						}
						else {
							clients.put(id, currClient);
							//Reply to the client saying they have been added
							outToClient.println("ADDED:" + id + ":" + TTL + "\n");
							id++;
						}
					}	
				}
				else if (line.contains("PING")) {
					//find the space in order to check id number
					int space = line.indexOf(" ");
					//if no space reply with an error 
					if (space == -1) {
						outToClient.println("ERROR: That is not a valid command\n");
					}
					else {
						String idNum = line.substring(space+1);
						//make sure second thing entered was an integer
						try {
							int id = Integer.parseInt(idNum);
						}
						catch (Exception e) {
							outToClient.println("ERROR: That is not a valid command\n");
							//close the socket and restart the loop if it is not
							socket.close();
							continue;
						}
						int id = Integer.parseInt(idNum);
						//check to see if ID is in the table or not
						if (clients.containsKey(id)) {
							//reset ttl for ping 
							clients.get(id).ttl = System.currentTimeMillis();
							outToClient.println("PONG:" + TTL + "\n");
						}
						//if not give an error 
						else {
							outToClient.println("ERROR: That is not a valid ID number\n");
						}
					}
				}
				else if (line.contains("LIST")) {
					//find the space in order to check id number
					int space = line.indexOf(" ");
					//if no space reply with an error 
					if (space == -1) {
						outToClient.println("ERROR: That is not a valid command\n");
					}
					else {
						String idNum = line.substring(space+1);
						//make sure second thing entered was an integer
						try {
							int id = Integer.parseInt(idNum);
						}
						catch (Exception e) {
							outToClient.println("ERROR: That is not a valid command\n");
							//close the socket and restart the loop if it is not
							socket.close();
							continue;
						}
						int id = Integer.parseInt(idNum);
						//check to see if ID is in the table or not
						if (clients.containsKey(id)) {
							//print out the list of clients
							outToClient.println("List: " + clients.size() + "\n");
							Enumeration<Integer> keys = clients.keys();
							while (keys.hasMoreElements()) {
								int currID = keys.nextElement();
								Client curr = clients.get(currID);
								outToClient.println(currID + ":" + curr.alias + ":" 
								+ curr.ip + ":" + curr.portNum + "\n");
							}
						}
						//if not give an error 
						else {
							outToClient.println("ERROR: That is not a valid ID number\n");
						}
					}
				}
				else if (line.contains("LOGOFF")) {
					//find the space in order to check id number
					int space = line.indexOf(" ");
					//if no space reply with an error 
					if (space == -1) {
						outToClient.println("ERROR: That is not a valid command\n");
					}
					else {
						String idNum = line.substring(space+1);
						//make sure second thing entered was an integer
						try {
							int id = Integer.parseInt(idNum);
						}
						catch (Exception e) {
							outToClient.println("ERROR: That is not a valid command\n");
							//close the socket and restart the loop if it is not
							socket.close();
							continue;
						}
						int id = Integer.parseInt(idNum);
						//check to see if ID is in the table or not
						if (clients.containsKey(id)) {
							//remove the client
							clients.remove(id);
							outToClient.println("DONE:" + id + "\n");
						}
						//if not give an error 
						else {
							outToClient.println("ERROR: That is not a valid ID number\n");
						}
					}
				}
				//If it is not a specified command give an error
				else {
					outToClient.println("ERROR: That is not a valid command\n");
				}
				//close the socket and go back to look for a new connection
				socket.close();
			}			
		}
		//If server doesn't work for whatever reason send an error 
		catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	//Use this to check for expired users each time someone connects
	public static void removeExpired(Hashtable<Integer, Client> clients) {
		Enumeration<Integer> keys = clients.keys();
		while (keys.hasMoreElements()) {
			int key = keys.nextElement();
			Client curr = clients.get(key);
			if (curr.expired()) {
				clients.remove(key);
			}
		}
	}
}