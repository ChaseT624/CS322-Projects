import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class DirectoryTest {

	public static String dirServer = "localhost";
	
	public static void main(String[] args) throws Exception {
		DirectoryClientConnector test = new DirectoryClientConnector(dirServer, 1, "test");
		try {
			test.logoff();
			System.out.println("Test failed");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test passed!");
		}
		System.out.println();
		try {
			test.getList();
			System.out.println("Test failed");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test passed!");
		}
		System.out.println();
		try {
			test.logon();
			System.out.println("Logon successful!");
		}
		catch (Exception e) {
			System.out.println("Test failed");
		}
		System.out.println();
		try {
			test.logon();
			System.out.println("Test failed!");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test passed!");
		}	
		System.out.println();
		if (test.getList().toString().contains("List: 1") && 
				test.getList().toString().contains("1:test:")) {
			System.out.print("Test Passed if the list is contains what it should!");
		}
		else {
			System.out.print("Test failed if the list does not contains what it should!");
		}
		System.out.println();
		System.out.println();
		DirectoryClientConnector test2 = new DirectoryClientConnector(dirServer, 2, "test2");
		DirectoryClientConnector test3 = new DirectoryClientConnector(dirServer, 3, "test3");
		DirectoryClientConnector test4 = new DirectoryClientConnector(dirServer, 4, "test4");
		try {
			test2.logon();
			System.out.println("Logon successful!");
		}
		catch (Exception e) {
			System.out.println("Test failed");
		}
		try {
			test3.logon();
			System.out.println("Logon successful!");
		}
		catch (Exception e) {
			System.out.println("Test failed");
		}
		try {
			test4.logon();
			System.out.println("Logon successful!");
		}
		catch (Exception e) {
			System.out.println("Test failed");
		}
		System.out.println();
		if (test.getList().toString().contains("List: 4") && 
				test.getList().toString().contains("1:test:") && 
				test.getList().toString().contains("2:test2:") && 
				test.getList().toString().contains("3:test3:") && 
				test.getList().toString().contains("4:test4:")) {
			System.out.print("Test Passed if the list is contains what it should!");
		}
		else {
			System.out.print("Test failed if the list does not contains what it should!");
		}
		System.out.println();
		System.out.println();
		try {
			test2.logoff();
			System.out.println("Logoff succesful!");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test failed!");
		}
		System.out.println();
		if (test.getList().toString().contains("List: 3") && 
				test.getList().toString().contains("1:test:") && 
				test.getList().toString().contains("3:test3:") && 
				test.getList().toString().contains("4:test4:")) {
			System.out.print("Test Passed if the list is contains what it should!");
		}
		else {
			System.out.print("Test failed if the list does not contains what it should!");
		}
		System.out.println();
		System.out.println();
		try {
			test2.getList();
			System.out.println("Test failed");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test passed!");
		}
		System.out.println();
		try ( Socket socket = new Socket(dirServer, 54321);
				BufferedReader inFromServer = new BufferedReader(
				new InputStreamReader(socket.getInputStream()));
				PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);
										)
				{	
					System.out.println("If this PING attempts does not cause an error test passed!");
					outToServer.println("PING 1");
					System.out.println(inFromServer.readLine());
					System.out.println();
				}
		catch (Exception e) {
			System.out.println("This test was unsucessful");
		}
		try ( Socket socket = new Socket(dirServer, 54321);
				BufferedReader inFromServer = new BufferedReader(
				new InputStreamReader(socket.getInputStream()));
				PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);
										)
				{	
			System.out.println("If this PING attempt causes an error test passed!");
			outToServer.println("PING 3343");
			System.out.println(inFromServer.readLine());
			System.out.println();	
				}
		catch (Exception e) {
			System.out.println("This test was unsucessful");
		}
		try {
			test.logoff();
			System.out.println("Logoff succesful!");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test failed!");
		}
		try {
			test3.logoff();
			System.out.println("Logoff succesful!");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test failed!");
		}
		try {
			test4.logoff();
			System.out.println("Logoff succesful!");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test failed!");
		}
		System.out.println();
		try {
			test.getList();
			System.out.println("Test failed");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test passed!");
		}
		System.out.println();
		try {
			test.logoff();
			System.out.println("Test failed");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Test passed!");
		}
		System.out.println();
		//To test if the PING times out correctly need to logon in own try catch 
		//because server closes socket after
		try ( Socket socket = new Socket(dirServer, 54321);
				BufferedReader inFromServer = new BufferedReader(
				new InputStreamReader(socket.getInputStream()));
				PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);
										)
				{	
					outToServer.println("LOGON 22 chase");
						
				}
		catch (Exception e) {
			System.out.println("This test was unsucessful");
		}
		try ( Socket socket = new Socket(dirServer, 54321);
				BufferedReader inFromServer = new BufferedReader(
				new InputStreamReader(socket.getInputStream()));
				PrintWriter outToServer = new PrintWriter(socket.getOutputStream(), true);
										)
				{	
				long start = System.currentTimeMillis();
				System.out.println("If this PING gives a error the server successfully "
						+ "removed expired data!");
				while ((System.currentTimeMillis() - start) / 1000 < DirectoryServer.TTL)
				{	
				}
				outToServer.println("PING 5");
				System.out.println(inFromServer.readLine());
						
				}
		catch (Exception e) {
			System.out.println("This test was unsucessful");
		}
		
	}
}
