
//Class to make a client object
public class Client {
	
	public String alias;
	public String ip;		
	public int portNum;
	public long ttl;
	
	//Construct the client setting the ttl equal to the time it was created to check against
	//the current time later on
	public Client(String ip, int portNum, String ali) {
		this.ip = ip;
		this.portNum = portNum;
		alias = ali;
		ttl = System.currentTimeMillis();	
	}
	
	//check whether or not the TTL has expired
	public boolean expired() {
		if ((System.currentTimeMillis() - ttl)/1000 < DirectoryServer.TTL) {
			return false;
		}
		else {
			return true;
		}
	}
	
	//check if everything is the same besides TTL
	public boolean same(Client check) {
		if (alias.equals(check.alias) && ip.equals(check.ip) && portNum == check.portNum) {
			return true;
		}
		return false;
	}
		
}